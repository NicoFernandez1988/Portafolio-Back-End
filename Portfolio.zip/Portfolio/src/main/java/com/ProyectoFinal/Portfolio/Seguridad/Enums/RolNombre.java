
package com.ProyectoFinal.Portfolio.Seguridad.Enums;


public enum RolNombre {
    ROLE_ADMIN, ROLE_USER
}
